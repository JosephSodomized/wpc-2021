def handle_order(order_request):
   print('I am going to handle your order')